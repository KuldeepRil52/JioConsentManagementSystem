# JCMS Preference Center SDK (React Native Android)

This SDK opens the JCMS Preference Center in a React Native app using WebView popup.

## 1) Install SDK (.tgz file)
After downloading the SDK file (`jcms-preference-center-1.0.0.tgz`), run in your React Native project:

```bash
npm i ./jcms-preference-center-1.0.0.tgz
# or
yarn add ./jcms-preference-center-1.0.0.tgz

2) Required dependency

This SDK uses react-native-webview, so install it in the host React Native app:

npm i react-native-webview

If iOS app is also used, run:

npx pod-install

3) Usage (example in end user app)

Use the SDK component in any screen:

import React, { useState } from "react";
import { Button } from "react-native";
import { JcmsPreferenceCenter } from "jcms-preference-center";

export default function MyScreen() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <Button title="Open Preference Center" onPress={() => setOpen(true)} />

      <JcmsPreferenceCenter
        visible={open}
        onClose={() => setOpen(false)}
        tenantId="YOUR_TENANT_ID"
        businessId="YOUR_BUSINESS_ID"
        secureCode="YOUR_SECURE_CODE"
        consentHandleId="YOUR_CONSENT_HANDLE_ID"
      />
    </>
  );
}