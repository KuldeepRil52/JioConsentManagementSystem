const integrationHtml = `<!doctype html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
      html, body {
        height: 100%;
        width: 100%;
        margin: 0;
        padding: 0;
        background: transparent;
      }
    </style>
  </head>
  <body></body>
</html>`;

export default integrationHtml;