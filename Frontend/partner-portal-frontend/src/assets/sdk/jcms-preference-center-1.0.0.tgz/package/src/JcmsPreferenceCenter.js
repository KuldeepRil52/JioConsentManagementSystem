import React, { useCallback, useRef } from "react";
import { Modal, View, StyleSheet } from "react-native";
import WebView from "react-native-webview";
import integrationHtml from "./integrationHtml";
import integrationCode from "./integrationCode";

export default function JcmsPreferenceCenter({
    visible,
    onClose,
    tenantId,
    businessId,
    secureCode,
    consentHandleId,
}) {
    const webRef = useRef(null);

    const bootstrapAndOpen = useCallback(() => {
        const js = `
      (function () {
        try {
          ${'${integrationCode}'}

          if (typeof window.loadPreferenceCenter === "function") {
            window.loadPreferenceCenter(
              ${JSON.stringify(consentHandleId || "")},
              ${JSON.stringify(tenantId || "")},
              ${JSON.stringify(businessId || "")},
              ${JSON.stringify(secureCode || "")}
            );
          } else {
            console.log("loadPreferenceCenter not found on window");
          }
        } catch (e) {
          console.log("Error in SDK bootstrap:", e);
        }
      })();
      true;
    `;

        // Replace placeholder with actual code before injecting
        const finalJs = js.replace("${integrationCode}", integrationCode);
        webRef.current?.injectJavaScript(finalJs);
    }, [consentHandleId, tenantId, businessId, secureCode]);

    return (
        <Modal visible={!!visible} transparent animationType="fade" onRequestClose={onClose}>
            <View style={styles.modalWrap}>
                <View style={styles.webWrap}>
                    <WebView
                        ref={webRef}
                        originWhitelist={["*"]}
                        javaScriptEnabled
                        domStorageEnabled
                        javaScriptCanOpenWindowsAutomatically
                        setSupportMultipleWindows={false}
                        source={{ html: integrationHtml }}
                        onLoadEnd={bootstrapAndOpen}
                        onMessage={(event) => {
                            console.log("JCMS SDK WebView message:", event.nativeEvent.data);
                        }}
                        onError={(event) => {
                            console.log("JCMS SDK WebView error:", event.nativeEvent);
                        }}
                        onHttpError={(event) => {
                            console.log("JCMS SDK WebView HTTP error:", event.nativeEvent);
                        }}
                    />
                </View>
            </View>
        </Modal>
    );
}

const styles = StyleSheet.create({
    modalWrap: { flex: 1, backgroundColor: "rgba(0,0,0,0.35)" },
    webWrap: { flex: 1 },
});